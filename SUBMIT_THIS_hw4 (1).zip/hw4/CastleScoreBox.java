package hw4;
import java.util.Arrays;

import api.ScoreBox;
/**
 * Score box that is satisfied by a Combination including
 * at least three dice of one value and three of a different value.
 * The score is the sum of all die values.
 * 
 * @author Josh Slick
 */
//TODO: this class must implement ScoreBox or extend another class that does
public class CastleScoreBox implements ScoreBox
{
	private String displayName;
	  private Combination dice;
  /**
   * Constructs a CastleScoreBox with the given display name.
   * @param displayName
   *   name for this score box
   */
  public CastleScoreBox(String displayName)
  {
	  this.displayName = displayName;
	    this.dice = null;
	  }

	  @Override
	  public boolean isFilled()
	  {
	    return dice != null;
	  }

	  @Override
	  public int getScore()
	  {
	    return isFilled() ? calculateScore() : 0;
	  }

	  @Override
	  public Combination getDice()
	  {
	    return dice;
	  }

	  @Override
	  public String getDisplayName()
	  {
	    return displayName;
	  }

	  @Override
	  public void fill(Combination dice)
	  {
	    if (dice == null || !dice.isComplete()) {
	      throw new IllegalStateException("Invalid combination for filling the score box.");
	    }
	    this.dice = dice;
	  }

	  @Override
	  public boolean isSatisfiedBy(int[] arr)
	  {
		  Arrays.sort(arr);

		    int count1 = 1; // Count for the first value
		    int count2 = 0; // Count for the second value

		    for (int i = 1; i < arr.length; i++) {
		        if (arr[i] == arr[i - 1]) {
		            count1++;
		        } else {
		            count2 = (arr[i] == arr[i - 1] + 1) ? 1 : 0;
		            count1 = 1;
		        }

		        // Check if there are at least three dice of one value and three of a different value
		        if (count1 >= 3 || count2 >= 3) {
		            return true;
		        }
		    }

		    return false;
		    }

	  @Override
	  public int getPotentialScore(int[] arr)
	  {
		  int potentialScore = Arrays.stream(arr).sum();
		    return potentialScore;
		    }

	  // Additional helper method to calculate the actual score for the filled dice
	  private int calculateScore()
	  {
	    if (dice == null) {
	      return 0;
	    }

	    int[] completedDice = dice.getCompletedDice();
	    int actualScore = 0;
	    for (int value : completedDice) {
	      actualScore += value;
	    }
	    return actualScore;
	  }
}
