package hw4;
import api.ScoreBox;
import java.util.Arrays;

/**
 * Score box that is based on counting dice that match
 * a particular target value (as specified in the constructor).
 * This category is satisfied by any Combination.  The score
 * is the sum of the dice that match the target.
 * 
 * @author Josh Slick
 */
//TODO: this class must implement ScoreBox or extend another class that does
public class MatchTargetScoreBox implements ScoreBox
{
	private String displayName;
	  private Combination dice;
	  private int whichValue;
  /**
   * Constructs a MatchTargetScoreBox with the given display name and 
   * target value.
   * @param displayName
   *   name for this score box
   * @param whichValue
   *   target value that must be matched for the dice to count toward the
   *   score
   */
  public MatchTargetScoreBox(String displayName, int whichValue)
  {
	  this.displayName = displayName;
	    this.whichValue = whichValue;
	    this.dice = null;
	  }

	  @Override
	  public boolean isFilled()
	  {
	    return dice != null;
	  }

	  @Override
	  public int getScore()
	  {
	    return isFilled() ? calculateScore() : 0;
	  }

	  @Override
	  public Combination getDice()
	  {
	    return dice;
	  }

	  @Override
	  public String getDisplayName()
	  {
	    return displayName;
	  }

	  @Override
	  public void fill(Combination dice)
	  {
	    if (dice == null || !dice.isComplete()) {
	      throw new IllegalStateException("Invalid combination for filling the score box.");
	    }
	    this.dice = dice;
	  }

	  @Override
	  public boolean isSatisfiedBy(int[] arr)
	  {
	    // Check if any die value matches the target value
	    for (int value : arr) {
	      if (value == whichValue) {
	        return true;
	      }
	    }
	    return false;
	  }

	  @Override
	  public int getPotentialScore(int[] arr)
	  {
		  int potentialScore = 0;
	        for (int value : arr) {
	            if (value == whichValue) {
	                potentialScore += value;
	            }
	        }
	        return potentialScore;
	  }

	  // Additional helper method to calculate the actual score for the filled dice
	  private int calculateScore()
	  {
	    if (dice == null) {
	      return 0;
	    }

	    int[] completedDice = dice.getCompletedDice();
	    int actualScore = 0;
	    for (int value : completedDice) {
	      if (value == whichValue) {
	        actualScore += value;
	      }
	    }
	    return actualScore;
	  }

}
