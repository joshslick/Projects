package hw4;

import java.util.Arrays;

import api.ScoreBox;

/**
 * Score box that is satisfied by a Combination including at least
 * four dice of one value and two of a different value.
 * The score is the sum of all die values.
 * 
 * Author: Josh Slick
 */
public class TowerScoreBox implements ScoreBox
{
  private String displayName;
  private Combination dice;

  /**
   * Constructs a TowerScoreBox with the given display name.
   * @param displayName
   *   name for this score box
   */
  public TowerScoreBox(String displayName)
  {
    this.displayName = displayName;
    this.dice = null;
  }

  @Override
  public boolean isFilled()
  {
    return dice != null;
  }

  @Override
  public int getScore()
  {
    return isFilled() ? dice.getAll().length : 0;
  }

  @Override
  public Combination getDice()
  {
    return dice;
  }

  @Override
  public String getDisplayName()
  {
    return displayName;
  }

  @Override
  public void fill(Combination dice)
  {
    if (dice == null || !dice.isComplete()) {
      throw new IllegalStateException("Invalid combination for filling the score box.");
    }
    this.dice = dice;
  }

  @Override
  public boolean isSatisfiedBy(int[] arr)
  {
     

	    // Helper method to check if there are at least four dice of one value
	    if (hasNMatchingDice(arr, 4)) {
	        // Helper method to check if there are at least two dice of a different value
	        return hasNMatchingDice(arr, 2, 2);
	    }

	    return false;
	}

  @Override
  public int getPotentialScore(int[] arr)
  {
	  if (!isSatisfiedBy(arr)) {
	        return 0;
	    }

	  int score = 0;

	    // Include the completed dice in the calculation
	    if (dice != null && dice.isComplete()) {
	        score += Arrays.stream(dice.getCompletedDice()).sum();
	    }
	    return score;
  }

  // Helper method to check if there are at least N dice with the same value
  private boolean hasNMatchingDice(int[] arr, int n)
  {
      for (int i = 1; i <= 6; i++) {
          int count = 0;
          for (int value : arr) {
              if (value == i) {
                  count++;
              }
          }
          if (count >= n) {
              return true;
          }
      }
      return false;
  }

  //  helper method to check if there are at least N dice with a different value
  private boolean hasNMatchingDice(int[] arr, int n, int differentValueCount)
  {
      int distinctValues = 0;
      for (int i = 1; i <= 6; i++) {
          for (int value : arr) {
              if (value == i) {
                  distinctValues++;
                  break;
              }
          }
      }
      return distinctValues >= differentValueCount;
  }
}
