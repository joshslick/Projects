package hw4;

import api.ScoreBox;
import java.util.Arrays;

/**
 * Score box for a short straight.  A Combination
 * with N dice satisfies this category only if it includes
 * N - 1 distinct consecutive values.  For a dice group that satisfies
 * this category, the score is a fixed value specified in the constructor;
 * otherwise, the score is zero.
 * 
 * Author: Josh Slick
 */
public class ShortStraightScoreBox implements ScoreBox
{
  private String displayName;
  private Combination dice;
  private int points;

  /**
   * Constructs a ShortStraightScoreBox with the given display name
   * and score.
   * @param displayName
   *   name of this score box
   * @param points
   *   points awarded for a dice group that satisfies this score box
   */  
  public ShortStraightScoreBox(String displayName, int points)
  {
    this.displayName = displayName;
    this.points = points;
    this.dice = null;
  }

  @Override
  public boolean isFilled()
  {
    return dice != null;
  }

  @Override
  public int getScore()
  {
    return isFilled() ? points : 0;
  }

  @Override
  public Combination getDice()
  {
    return dice;
  }

  @Override
  public String getDisplayName()
  {
    return displayName;
  }

  @Override
  public void fill(Combination dice)
  {
    if (dice == null || !dice.isComplete()) {
      throw new IllegalStateException("Invalid combination for filling the score box.");
    }
    this.dice = dice;
  }

  @Override
  public boolean isSatisfiedBy(int[] arr)
  {
    // Sort the array in ascending order
    Arrays.sort(arr);

    // Check if the array forms a short straight
    for (int i = 0; i < arr.length - 1; i++) {
      if (arr[i] + 1 != arr[i + 1]) {
        return false;
      }
    }
    return true;
  }

  @Override
  public int getPotentialScore(int[] arr)
  {
    return isSatisfiedBy(arr) ? points : 0;
  }

}
