package hw4;
import api.ScoreBox;
import hw4.Combination;

/**
 * Score box for all dice the same.  A Combination
 * with N dice satisfies this category only if all N
 * values are the same.  For a Combination that satisfies
 * this category, the score is a fixed value specified in the constructor;
 * otherwise, the score is zero.
 * 
 * @author Josh Slick
 */
// TODO: this class must implement ScoreBox or extend another class that does
public class AllMatchScoreBox implements ScoreBox
{
	private String displayName;
	  private int targetValue;
	  private Combination dice;
  /**
   * Constructs a AllMatchScoreBox with the given display name
   * and score.
   * @param displayName
   *   name of this score box
   * @param points
   *   points awarded for a combination that satisfies this score box
   */  
  public AllMatchScoreBox(String displayName, int points)
  {
	  this.displayName = displayName;
	    this.targetValue = targetValue;
	    this.dice = null;
	  }

	  @Override
	  public boolean isFilled() {
	    return dice != null;
	  }

	  @Override
	  public int getScore() {
	    return isFilled() ? calculateScore() : 0;
	  }

	  @Override
	  public Combination getDice() {
	    return dice;
	  }

	  @Override
	  public String getDisplayName() {
	    return displayName;
	  }

	  @Override
	  public void fill(Combination dice) {
	    if (dice == null || !dice.isComplete()) {
	      throw new IllegalStateException("Invalid combination for filling the score box.");
	    }
	    this.dice = dice;
	  }

	  @Override
	  public boolean isSatisfiedBy(int[] arr) {
		  for (int value : arr) {
	            if (value == targetValue) {
	                return true;
	            }
	        }
	        return false;
	  }

	  @Override
	  public int getPotentialScore(int[] arr) {
	    // Calculate the sum of values that match the target value
		  int potentialScore = 0;
	        for (int value : arr) {
	            if (value == targetValue) {
	                potentialScore += value;
	            }
	        }
	        return potentialScore;
	    }
	  

	  // Additional helper method to calculate the actual score for the filled dice
	  private int calculateScore() {
	    if (dice == null) {
	      return 0;
	    }

	    int[] completedDice = dice.getCompletedDice();
	    int actualScore = 0;
	    for (int value : completedDice) {
	      if (value == targetValue) {
	        actualScore += value;
	      }
	    }
	    return actualScore;
	  }
	}

