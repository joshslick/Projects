package hw4;

import java.util.ArrayList;
import java.util.Random;

import api.GameConfiguration;
import api.ScoreBox;

/**
 * Game state for dice games such as MaxiYatzy.  The game includes a
 * <code>GameConfiguration</code> object along with two lists of 
 * <code>ScoreBox</code> objects, one for the upper section 
 * and one for the lower section. (Note that the only actual distinction
 * between the two sections is that the upper section scores are 
 * added up and checked to see whether they exceed the upper section 
 * bonus cutoff; if so, the upper section bonus is added to the score.)
 * This class is also responsible for
 * maintaining a current Combination (group of dice) and counting the number of 
 * rolls. 
 * <p>
 * Most of the game state is stored in the associated <code>ScoreBox</code>
 * objects, each of which knows its contribution to the overall
 * score, obtained via its <code>getScore</code> method.
 * 
 * @author Josh Slick
 */
public class MaxiYatzy
{
	 private GameConfiguration config;
	  private ArrayList<ScoreBox> upperSection;
	  private ArrayList<ScoreBox> lowerSection;
	  private Combination currentCombination;
	  private int rollCount;

  /**
   * Constructs a new MaxiYatzy game based on the given configuration. 
   * Initially the upper section and lower section lists are
   * empty.
   * @param config
   *   configuration to use for this game
   * @param rand
   *   random number generator to use for rolling dice
   */
  public MaxiYatzy(GameConfiguration config, Random rand)
  {
	    this.config = config;
	    this.upperSection = new ArrayList<>();
	    this.lowerSection = new ArrayList<>();
	    this.currentCombination = new Combination(config.getNumDice());
	    this.rollCount = 0;
  }
  
  /**
   * Adds a score box to the lower section of this game.
   * @param box
   *   score box to add
   */
  public void addLowerSectionScoreBox(ScoreBox box)
  {
	  lowerSection.add(box);
  }
  
  /**
   * Adds a score box to the upper section of this game.
   * @param box
   *   score box to add
   */  
  public void addUpperSectionScoreBox(ScoreBox box)
  {
	  upperSection.add(box);
  }
  
  /**
   * Returns the list of score boxes in the upper section 
   * for this game.
   * @return
   *   list of score boxes in the upper section
   */
  public ArrayList<ScoreBox> getUpperSection()
  {
	  return upperSection;
  }
  
  /**
   * Returns the list of score boxes in the lower section
   * for this game.
   * @return
   *   list of score boxes for the lower section
   */
  public ArrayList<ScoreBox> getLowerSection()
  {
    return lowerSection;
  }
  
  /**
   * Starts a new turn by creating a new Combination
   * and updating the available rolls according to this
   * game's configuration.  If there is already a
   * current Combination that is not complete, this
   * method does nothing.
   */
  public void startTurn()
  {
	  if (config == null) {
		    // Handle the case where config is not initialized
		    return;
		  }
		  if (currentCombination.isComplete()) {
		    currentCombination = new Combination(config.getNumDice());
		  }
		  rollCount = config.getMaxRolls();
		}
  
  
  /**
   * Returns the remaining number of rolls for this turn.
   * The value returned is always zero if the current Combination
   * is complete, even if the configuration allows unused
   * rolls to be saved for future turns.
   * @return
   *   number of rolls
   */
  public int getRemainingRolls()
  {    
	  if (currentCombination.isComplete()) {
	      return 0;
	    } else {
	      return rollCount;
	    }
  }
  
  /**
   * Rolls the available dice in the current Combination.
   * That is, the available die values are replaced by randomly
   * generated values in the range 1 through the given maximum (according
   * to this game's configuration). If there are no more remaining
   * rolls, all available dice in the current Combination are
   * moved to the completed state.
   */
  public void rollAvailableDice()
  {
	  if (!currentCombination.isComplete() && rollCount > 0) {
	        Random random = new Random();
	        int[] newValues = new int[currentCombination.getNumDice()];

	        for (int i = 0; i < newValues.length; i++) {
	            newValues[i] = random.nextInt(6) + 1; 
	           
	        }

	        // Update availableDice in currentCombination
	        currentCombination.updateAvailableDice(newValues);

	        // Decrease the remaining roll count
	        rollCount--;

	        // If no more remaining rolls, move available dice to completed state
	        if (rollCount == 0) {
	            currentCombination.chooseAll();
	        }
	    }
	}
  
  /**
   * Returns the current Combination (group of dice).  
   * @return
   *   current group of dice
   */
  public Combination getCurrentDice()
  {
    return currentCombination;
  }
  
  /**
   * Returns true if the game is over.  The game is considered over
   * when all score boxes are filled.
   * @return
   *   true if the game is over, false otherwise
   */
  public boolean isOver()
  {
	  for (ScoreBox box : upperSection) {
	      if (!box.isFilled()) {
	        return false;
	      }
	    }

	    for (ScoreBox box : lowerSection) {
	      if (!box.isFilled()) {
	        return false;
	      }
	    }

	    return true;
	  }
  
  
  /**
   * Returns the total score for the filled upper section score boxes
   * (not including the upper section bonus, if any).
   * @return
   *   upper section total score
   */
  public int getUpperSectionTotal()
  {
	  int upperSectionTotal = 0;

	    for (ScoreBox box : upperSection) {
	      if (box.isFilled()) {
	        upperSectionTotal += box.getScore();
	      }
	    }

	    return upperSectionTotal;
	  }
  
  
  /**
   * Returns the total score for the filled lower section score boxes.
   * @return
   *   lower section total score
   */
  public int getLowerSectionTotal()
  {
	  int lowerSectionTotal = 0;

	    for (ScoreBox box : lowerSection) {
	      if (box.isFilled()) {
	        lowerSectionTotal += box.getScore();
	      }
	    }

	    return lowerSectionTotal;
	  
  }
  
  /**
   * Returns the total score for all categories including the upper section
   * bonus, if any.
   * @return
   *   total score for all categories
   */
  public int getTotalScore()
  {
	  int upperSectionTotal = getUpperSectionTotal();
	    int lowerSectionTotal = getLowerSectionTotal();

	    // Calculate upper section bonus (if applicable)
	    int upperSectionBonus = (upperSectionTotal >= config.getUpperSectionBonusCutoff()) ?
	        config.getUpperSectionBonus() : 0;

	    // Calculate total score
	    return upperSectionTotal + lowerSectionTotal + upperSectionBonus;
	  }
  
  /**
   * Returns the upper section bonus if one is currently being applied,
   * otherwise returns zero. 
   * @return
   *    upper section bonus if applicable, otherwise zero
   */
  public int getUpperSectionBonus()
  {
	  int upperSectionTotal = getUpperSectionTotal();
	    
	    // Check if the upper section bonus is currently being applied
	    if (upperSectionTotal >= config.getUpperSectionBonusCutoff()) {
	      return config.getUpperSectionBonus();
	    } else {
	      return 0;
	    }
	  }
}
