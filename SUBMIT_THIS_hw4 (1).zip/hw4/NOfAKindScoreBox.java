package hw4;
import api.ScoreBox;
import java.util.Arrays;
/**
 * Score box for a given number N of matching dice, where N is specified
 * in the constructor.  A Combination satisfies this category only if it has 
 * (at least) N dice that are the same.  For a Combination that satisfies 
 * this category, the score is the sum of the N dice that have the same value.
 * If there are multiple groups of N with the same value, the group with highest value 
 * is used for the score.  For example, if N is 3 and the combination
 * is (2, 2, 2, 5, 5, 5, 5, 6), the score is 15.
 * Author : Josh Slick
 */
//TODO: this class must implement ScoreBox or extend another class that does
public class NOfAKindScoreBox implements ScoreBox
{
	private String displayName;
	  private Combination dice;
	  private int howMany;
  /**
   * Constructs a NOfAKindScoreBox with the given display name
   * and score.
   * @param displayName
   *   name of this score box
   * @param howMany
   *   how many dice must match to satisfy this score box
   */  
  public NOfAKindScoreBox(String displayName, int howMany)
  {
	  this.displayName = displayName;
	    this.howMany = howMany;
	    this.dice = null;
	  }

	  @Override
	  public boolean isFilled()
	  {
	    return dice != null;
	  }

	  @Override
	  public int getScore()
	  {
	    return isFilled() ? calculateScore() : 0;
	  }

	  @Override
	  public Combination getDice()
	  {
	    return dice;
	  }

	  @Override
	  public String getDisplayName()
	  {
	    return displayName;
	  }

	  @Override
	  public void fill(Combination dice)
	  {
	    if (dice == null || !dice.isComplete()) {
	      throw new IllegalStateException("Invalid combination for filling the score box.");
	    }
	    this.dice = dice;
	  }

	  @Override
	  public boolean isSatisfiedBy(int[] arr)
	  {
	    // Sort the array in ascending order
	    Arrays.sort(arr);

	    // Check if there is a group of at least 'howMany' matching dice
	    for (int i = 0; i <= arr.length - howMany; i++) {
	      if (arr[i] == arr[i + howMany - 1]) {
	        return true;
	      }
	    }
	    return false;
	  }

	  @Override
	  public int getPotentialScore(int[] arr)
	  {
		  if (isSatisfiedBy(arr)) {
	            // Calculate the sum of the matching dice
	            int sum = 0;
	            for (int i = 0; i <= howMany; i++) {
	                sum += arr[i];
	            }
	            return sum;
	        } else {
	            return 0;
	        }
	    }

	  // Additional helper method to calculate the actual score for the filled dice
	  private int calculateScore()
	  {
	    if (dice == null) {
	      return 0;
	    }

	    int[] completedDice = dice.getCompletedDice();
	    Arrays.sort(completedDice);

	    // Find the group with at least 'howMany' matching dice
	    for (int i = 0; i <= completedDice.length - howMany; i++) {
	      if (completedDice[i] == completedDice[i + howMany - 1]) {
	        // Calculate the sum of the matching dice
	        int sum = 0;
	        for (int j = i; j < i + howMany; j++) {
	          sum += completedDice[j];
	        }
	        return sum;
	      }
	    }
	    return 0;
	  }

}
