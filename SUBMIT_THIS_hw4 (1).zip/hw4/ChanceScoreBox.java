package hw4;

import api.ScoreBox;
import hw4.Combination;
import hw4.MaxiYatzy;
/**
 * Score box that is satisfied by any Combination.
 * The score is the sum of all die values.
 * 
 * @author Josh Slick
 */
//TODO: this class must implement ScoreBox or extend another class that does
public class ChanceScoreBox implements ScoreBox
{
	 private String displayName;
	  private Combination dice;
  /**
   * Constructs a ChanceScoreBox with the given display name.
   * @param displayName
   *   name for this score box
   */
  public ChanceScoreBox(String displayName)
  {
	  this.displayName = displayName;
	    this.dice = null;
    // TODO
  }

  @Override
  public boolean isFilled()
  {
    // TODO Auto-generated method stub
	  return dice != null;
  }

  @Override
  public int getScore()
  {
	  if (dice == null || !dice.isComplete()) {
		    return 0; // Return 0 if the combination is not valid
		  }

		  // Calculate the sum of all die values in the completed dice
		  int[] completedDice = dice.getCompletedDice();
		  int actualScore = 0;
		  for (int value : completedDice) {
		    actualScore += value;
		  }

		  return actualScore;
  }

  @Override
  public Combination getDice()
  {
    // TODO Auto-generated method stub
    return dice;
  }

  @Override
  public String getDisplayName()
  {
    // TODO Auto-generated method stub
    return displayName;
  }

  @Override
  public void fill(Combination dice)
  {
	  if (dice == null || !dice.isComplete()) {
		    throw new IllegalStateException("Invalid combination for filling the score box.");
		  }

		  // Store the provided combination
		  this.dice = dice;
    
  }

  @Override
  public boolean isSatisfiedBy(int[] arr)
  {
    // TODO Auto-generated method stub
    return true;
  }

  @Override
  public int getPotentialScore(int[] arr)
  {
	  int potentialScore = 0;
	  for (int value : arr) {
	    potentialScore += value;
	  }
	  return potentialScore;
	}

}
