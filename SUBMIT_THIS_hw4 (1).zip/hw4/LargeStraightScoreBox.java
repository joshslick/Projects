package hw4;
import java.util.Arrays;

import api.ScoreBox;
/**
 * Score box for a large straight.  A Combination
 * with N dice satisfies this category only if it consists of
 * N distinct consecutive values.  For a dice group that satisfies
 * this category, the score is a fixed value specified in the constructor;
 * otherwise, the score is zero.
 * 
 * @author Josh Slick
 */
//TODO: this class must implement ScoreBox or extend another class that does
public class LargeStraightScoreBox implements ScoreBox
{
	 private String displayName;
	  private Combination dice;
	  private int points;

  /**
   * Constructs a LargeStraightScoreBox with the given display name
   * and score.
   * @param displayName
   *   name of this score box
   * @param points
   *   points awarded for a dice group that satisfies this score box
   */  
  public LargeStraightScoreBox(String displayName, int points)
  {
	  this.displayName = displayName;
	    this.points = points;
	    this.dice = null;

	  /**
	   * Constructs a LargeStraightScoreBox with the given display name
	   * and score.
	   * @param displayName
	   *   name of this score box
	   * @param points
	   *   points awarded for a dice group that satisfies this score box
	   */  
	 
	  }

	  @Override
	  public boolean isFilled()
	  {
	    return dice != null;
	  }

	  @Override
	  public int getScore()
	  {
	    return isFilled() ? points : 0;
	  }

	  @Override
	  public Combination getDice()
	  {
	    return dice;
	  }

	  @Override
	  public String getDisplayName()
	  {
	    return displayName;
	  }

	  @Override
	  public void fill(Combination dice)
	  {
	    if (dice == null || !dice.isComplete()) {
	      throw new IllegalStateException("Invalid combination for filling the score box.");
	    }
	    this.dice = dice;
	  }

	  @Override
	  public boolean isSatisfiedBy(int[] arr)
	  {
	    // Sort the array in ascending order
	    Arrays.sort(arr);

	    // Check for a large straight pattern 
	    for (int i = 0; i < arr.length - 1; i++) {
	      if (arr[i] + 1 != arr[i + 1]) {
	        return false;
	      }
	    }
	    return true;
	  }

	  @Override
	  public int getPotentialScore(int[] arr)
	  {
	    return isSatisfiedBy(arr) ? points : 0;
	  }

}
