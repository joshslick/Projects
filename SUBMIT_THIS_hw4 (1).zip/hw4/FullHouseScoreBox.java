package hw4;
import java.util.Arrays;

import api.ScoreBox;
/**
 * Score box that is satisfied by a Combination including
 * at least three dice of one value and two of a different value.
 * The score is the sum of all die values.
 * 
 * @author Josh Slick
 */
//TODO: this class must implement ScoreBox or extend another class that does
public class FullHouseScoreBox implements ScoreBox
{
	private String displayName;
	  private Combination dice;
  /**
   * Constructs a FullHouseScoreBox with the given display name.
   * @param displayName
   *   name for this score box
   */
  public FullHouseScoreBox(String displayName)
  {
	  this.displayName = displayName;
	    this.dice = null;
	  }

	  @Override
	  public boolean isFilled()
	  {
	    return dice != null;
	  }

	  @Override
	  public int getScore()
	  {
	    return isFilled() ? calculateScore() : 0;
	  }

	  @Override
	  public Combination getDice()
	  {
	    return dice;
	  }

	  @Override
	  public String getDisplayName()
	  {
	    return displayName;
	  }

	  @Override
	  public void fill(Combination dice)
	  {
	    if (dice == null || !dice.isComplete()) {
	      throw new IllegalStateException("Invalid combination for filling the score box.");
	    }
	    this.dice = dice;
	  }

	  @Override
	  public boolean isSatisfiedBy(int[] arr)
	  {
		  Arrays.sort(arr);

		  // Check for the Full House pattern 
		  boolean firstTwoSame = arr[0] == arr[1];
		  boolean lastThreeSame = arr[2] == arr[3] && arr[3] == arr[4];

		  return (firstTwoSame && lastThreeSame) || (!firstTwoSame && arr[0] == arr[2] && arr[3] == arr[4]);
	  }

	  @Override
	  public int getPotentialScore(int[] arr)
	  {
		  if (isSatisfiedBy(arr)) {
			    // Calculate the sum of all die values
			    int sum = 0;
			    for (int value : arr) {
			      sum += value;
			    }
			    return sum;
			  } else {
			    return 0;
			  }
	  }

	  // Additional helper method to calculate the actual score for the filled dice
	  private int calculateScore()
	  {
	    if (dice == null) {
	      return 0;
	    }

	    int[] completedDice = dice.getCompletedDice();
	    int actualScore = 0;
	    for (int value : completedDice) {
	      actualScore += value;
	    }
	    return actualScore;
	  }
}
